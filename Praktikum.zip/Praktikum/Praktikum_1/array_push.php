<!DOCTYPE html>
<html>
<body>
<?php
	$tims = ['george', 'hill', 'phillip', 'curtis'];
	array_push($tims, 'julius');
	foreach($tims as $person) {
		echo $person . '<br/>';
	}
?>
</body>
</html>