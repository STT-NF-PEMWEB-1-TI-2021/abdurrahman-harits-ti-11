<?php
// devinisikan variable
$nama = "George Hill";
$umur = 16;
$berat = 75.2;

echo "<br/> Nama : $nama";
echo "<br/> umur : $umur";
echo "<br/> berat : $berat";

echo "<br/> Hello $nama Apakabar";
echo "<br/> Hai nama saya $nama umur saya $umur berat badan saya $berat kg, salam kenal semua";
echo "<hr>";
?>