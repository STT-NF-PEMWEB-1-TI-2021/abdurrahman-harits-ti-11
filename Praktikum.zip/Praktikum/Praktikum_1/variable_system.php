<?php
echo 'Document Root' .$_SERVER["DOCUMENT_ROOT"];
echo '<br/> Nama file' .$_SERVER["PHP_SELF"];
?>