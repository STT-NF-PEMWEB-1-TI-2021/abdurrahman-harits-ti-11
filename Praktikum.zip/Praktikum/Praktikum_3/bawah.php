<footer>
    <p>Created by Hearts <a href="https://elena.nurulfikri.ac.id/"> STT-NF </a> 2021 copyright </p>
</footer>
</body>

</html>